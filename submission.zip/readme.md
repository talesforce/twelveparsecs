## Setup
1.  run this code and login with member@topcoder.com / t0pc0d3r
2.  If you want to point it to you sfdc org here is the unmanaged package for the object setup:
 [unamangaged package](https://login.salesforce.com/packaging/installPackage.apexp?p0=04t15000000l6nO)

See 'Deployment Guide.doc' in docs folder for relevant documentation. It also inculdes link for the new video overview.