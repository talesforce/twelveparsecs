//
//  SampleRequestListViewController.h
//  SFDCOfflinePoc
//
//  Created by PAULO VITOR MAGACHO DA SILVA on 1/24/16.
//  Copyright © 2016 Topcoder Inc. All rights reserved.
//

#import "BaseListViewController.h"

@interface SampleRequestListViewController : BaseListViewController

@end
